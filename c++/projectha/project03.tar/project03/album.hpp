//Hanan sedaghat pisheh
#ifndef TTT
#define TTT
#include "JSONDataObject.hpp"
#include<fstream>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<sstream>
#include "AlbumImage.hpp"
//#include"Tracks.hpp"
class Artist;
class Tracks;
class Album: public JSONDataObject {
public:
  Album();
  ~Album();
  std::string title();// { return _title;}
  unsigned albumID();//{return _albumID;}
  unsigned numImages();//{return _numImages;}
  unsigned artistID();//{return _artistID;}
  unsigned numTracks();//{return _numTracks;}
  std::string genres();//{return _genres;}
  std::string year();//{return _year;}
  void print();
  void parseFromJSONstream(std::fstream &stream);
  std::string htmlString();
  void setTracks(Tracks *tracks){ _tracks=tracks; }
  void setArtist(Artist *artist){ _artist=artist; }
  Artist *artist() { return _artist; } 
  Tracks *tracks() { return _tracks; } 

  AlbumImage *&primaryImage() { return _primaryAlbumImage;   }
  AlbumImage *&secondaryImage()  { return _secondaryAlbumImage; }

private:
  std::string _title, _genres, _year;
  unsigned _albumID, _numTracks, _numImages;
  bool cachedTitle, cachedGenres, cachedYear, cachedNumImages, cachedAlbumD, cachedNumTracks, cachedArtistID;
  unsigned _artistID ;
  Tracks *_tracks;
  Artist *_artist;
  AlbumImage *_primaryAlbumImage;
  AlbumImage *_secondaryAlbumImage;
  
};

    
#endif
