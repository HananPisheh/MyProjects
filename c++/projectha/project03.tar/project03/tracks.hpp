#ifndef TRACKS
#define TRACKS

#include "JSONArray.hpp"
#include "JSONDataObject.hpp"
#include "Track.hpp"


class Tracks: public JSONArray
{
public:
  Tracks(){}
  ~Tracks(){}

  int numTracks();

  void addTrack(Track *tracks);

  Tracks *TracksalbumWithID(unsigned int aID);

  void loadTracksFromFile(std::string TracksFileName);

  std::string htmlString();

  JSONDataObject *jsonObjectNode() { return new Track();  }

  //void setTrackForAlbums(Track *tracks);
  //void setImagesForArtists(ArtistImages *);

  std::vector<Track *> *listOfTracks() { return (std::vector<Track *> *) _listOfDataObjects; }

  void runAsserts();  // used for checking the integrity of this class.
};

#endif
