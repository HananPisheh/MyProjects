#ifndef ARTISTIMAGES
#define ARTISTIMAGES
#include "ArtistImage.hpp"
#include "JSONArray.hpp"
#include <vector>


class ArtistImages: public JSONArray
{
public:
  ArtistImages();
  ~ArtistImages();
  int numArtistImage();
  void addArtistImage(ArtistImage * artistImg );
  ArtistImages *artistImageWithID(unsigned int aID);
  void loadArtistImageFromFile(std::string ArtistImageFileName);
  std::string htmlString();
  JSONDataObject *jsonObjectNode() { return new ArtistImage();  }
  std::vector<ArtistImage *> *listOfArtistImage() { return (std::vector<ArtistImage *> *) _listOfDataObjects;  }
  void runAsserts();  // used for checking the integrity of this class.
};

#endif


