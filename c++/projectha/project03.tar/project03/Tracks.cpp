#include "Tracks.hpp"
//#include "Track.hpp"

//Tracks::Tracks{}

int Tracks::numTracks(){
  return  listOfTracks()->size();}

void Tracks::addTrack(Track *tracks){

  listOfTracks()->push_back(tracks);
}

Tracks *Tracks::TracksalbumWithID(unsigned int aID){
  Tracks *t = new Tracks();
  for(auto& it : *listOfTracks())
    {
      if(it->albumID()==aID){
	t->addTrack(it);
      }
    }
return t;
}

void Tracks::loadTracksFromFile(std::string TracksFileName)

{
  std::fstream trackStream;
  trackStream.open(TracksFileName.c_str(), std::fstream::in);
  parseJSONArray(trackStream);
  trackStream.close();
}



std::string Tracks::htmlString(){
  std::string ss;
  // ss='first';
  for(int i=0; i<numTracks();i++)
    ss+=listOfTracks()->at(i)->htmlString();
  return ss;
  
  //  for(auto&i :*listOfTracks())
  //i->htmlString();
}

void Tracks::runAsserts(){}// used for checking the integrity of this class.


//Tracks::~Tracks{}
