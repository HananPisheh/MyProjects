Hanan sedaghat pisheh

All function works properly, master file is a master.html which contain all artists and albums and track.
There is a foler name htmlfiles which contain each albums track.
everything works properly.


Thanks,
Hanan
