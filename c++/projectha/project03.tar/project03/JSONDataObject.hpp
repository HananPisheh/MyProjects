
#ifndef JSONO
#define JSONO

#include<vector>
#include<fstream>
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include "JSONDataItem.hpp"

using namespace std;

class JSONDataObject {

public:

  JSONDataObject();
  virtual ~JSONDataObject();
  vector<JSONDataItem *> *listOfDataItems() const { return _listOfDataItems; }
  void parseFromJSONstream(fstream &stream);
   virtual void print();
  string valueForStringAttribute(string s);
  int valueForIntegerAttribute(string s);

private:
  vector<JSONDataItem *> *_listOfDataItems;
};

#endif
