
//Hanan Sedaghat Pisheh
#include"Album.hpp"
#include"Artist.hpp"
//#include "Tracks.hpp"
using namespace::std;
//string key;
//string value;
//unsigned number;

Album::Album(){
  _title="UNKNOWN";
  _genres="UNKNOWN";
  _year="UNKNOWN";
  _albumID=0;
  _numTracks=0;
  _numImages=0;
  _artistID=0;
  cachedTitle= cachedGenres= cachedYear= cachedNumImages=cachedAlbumD= cachedNumTracks= cachedArtistID=false;  
  _primaryAlbumImage= NULL; //new AlbumImage();
  _secondaryAlbumImage= NULL; //new AlbumImage();
  _artist=new Artist();
  _tracks=new Tracks();
}

string Album:: title() {
    if(cachedTitle)
  return  _title;
     cachedTitle=true;
    return _title=valueForStringAttribute( "title");}

unsigned Album::albumID() {
  if(cachedAlbumD)
    return  _albumID;
   cachedAlbumD=true;
   return  _albumID=valueForIntegerAttribute( "album_id");}

unsigned Album::numImages() {
  if(cachedNumImages)
  return _numImages;
  cachedNumImages=true;
  return _numImages=valueForIntegerAttribute( "num_images");}

unsigned Album::artistID() {
  if(cachedArtistID)
  return _artistID ;
  cachedArtistID=true;
  return _artistID=valueForIntegerAttribute( "artist_id");}

unsigned Album::numTracks() {
  if(cachedNumTracks)
  return _numTracks;
  cachedNumTracks=true;
  return _numTracks=valueForIntegerAttribute( "num_tracks");}

string Album::genres() {
  if( cachedGenres)
  return _genres;
 cachedGenres=true;
  return _genres=valueForStringAttribute( "genres");}

string Album::year() {
  if(cachedYear)
   return  _year;
  cachedYear=true;
  return  _year=valueForStringAttribute( "year");}


void Album::print(){
  
  cout<<"title= "<<title()<<endl;
  cout<<"album_id= "<<valueForIntegerAttribute("album_id")<<endl;
  cout<<"genres= "<<valueForStringAttribute("genres")<<endl;
  cout<<"num_images= "<<valueForIntegerAttribute("num_images")<<endl;
   cout<<"num_tracks= "<<valueForIntegerAttribute("num_tracks")<<endl;
  cout<<"year= "<<valueForStringAttribute("year")<<endl;
  cout<<"artist_id= "<<valueForIntegerAttribute("artist_id")<<endl;
  cout<< endl;
  cout<<endl;
  cout <<endl;
 
}

string Album::htmlString(){

  stringstream begin;
  begin<<"<li><p><strong>"<< title()<<"</strong></p>";

  
    stringstream ss;

    //"<table class=\"albumInfo\">"
    ss<<"<tr><td class=\"aTitle\" colspan=2>"<<title();
    ss<<"</td></tr><tr><td class=\"tdNarrow\">Artist id:</td><td class=\"value\"> "<< artist()->artistName();
    ss<<"</td></tr><tr><td class=\"tdNarrow\">Genres:</td><td class=\"value\">"<<genres();
    ss<<":Non-Music</td></tr><tr><td>Year:</td><td class=\"value\">"<<year();
    ss<<"</td></tr>";

    //string str="";
    //fstream outfile;
    //outfile.open("album_template.html");
    //while(outfile.good()){
    //char c;
    //outfile.get(c);
    //str += c;
    //}
    //str.replace(str.find("<% album_details %>"),19,ss.str());
    //outfile.close();
    stringstream mid;
    mid<<"<table class=\"albumInfo\"><tr><td class=\"aTitle\" colspan=2>"<<title();
    mid<<"</td></tr><tr><td class=\"tdNarrow\">Artist:</td><td class=\"value\">"<<artist()->artistName();
    mid<<"</td></tr><tr><td class=\"tdNarrow\">Genres:</td><td class=\"value\">"<<genres();
    mid<<"</td></tr><tr><td>Year:</td><td class=\"value\">"<<year();
    mid<<"</td></tr></table><div class=\"clear\">&nbsp;</div><h2>Tracklist</h2><table class=\"tracks\">";



    stringstream end;
    end<<"</table></li>";
    
   //   cout<<str; 
  string t = "";
  if(primaryImage() != nullptr)
    t = primaryImage()->htmlString();
  else if(secondaryImage() != nullptr)
    t = secondaryImage()->htmlString();
  
  
  return begin.str() + t + mid.str() + tracks()->htmlString() + end.str();
}


Album::~Album()
{}




