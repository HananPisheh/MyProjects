
//Hanan sedaghat pisheh

#include "AlbumImage.hpp"
#include "Artist.hpp"
#include "Track.hpp"

AlbumImage::AlbumImage(){
_height= 0;
_type="primary";
_uri="UNKNOWN";
_width=0;
// _primaryAlbumImage=NULL;
// _secondaryAlbumImage=NULL;
_albumID=0;
cachedTypeIMG =cachedURL =cachedAlbumIMGID=false;
}
//string AlbumImage::Type(){return _type;}
unsigned AlbumImage::albumID()
{
  if(cachedAlbumIMGID )
    return  _albumID;
  cachedAlbumIMGID= true;
  return  _albumID= valueForIntegerAttribute( "album_id");
}

string AlbumImage::Type()
{
 if(cachedTypeIMG )
  return  _type;
 cachedTypeIMG= true;
return  _type= valueForStringAttribute("type");
}


string AlbumImage::URL()
{
  if(cachedURL )
    return  _uri;
  cachedURL= true;
  return  _uri= valueForStringAttribute("uri");
}




void AlbumImage::print(){
  cout<<"Type= "<<valueForStringAttribute("type")<<endl;
  cout<<"height "<<valueForIntegerAttribute("height")<<endl;
  cout<<"width"<<valueForIntegerAttribute("width")<<endl;
  cout<<"URI "<<valueForStringAttribute("uri")<<endl;
  cout<<"albumID "<<valueForIntegerAttribute("album_id")<<endl;
  cout<< endl;
  cout<<endl;
  cout <<endl;
  }
//  void AlbumImage::parseFromJSONstream(std::fstream &stream){}
  std::string AlbumImage::htmlString(){
    // string str2="not a string";
    stringstream ss;
   
    ss<<"<img class=\"image\" width= "<<valueForIntegerAttribute("width")/1.6<< " height= "<<valueForIntegerAttribute("height")/1.6<< " src=\"";
    ss << URL() <<"\">";
    // string str1=Type();
	//    if(str1.compare(str2) == 0)
	//cout <<albumID()<< URL() <<endl;
    return ss.str();
  }




  //void setTracks(Tracks *tracks);
  //void setArtist(Artist *artist);
  
AlbumImage::~AlbumImage(){}

