
#ifndef JSONA
#define JSONA

#include<vector>
#include<fstream>
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include "JSONDataItem.hpp"
#include "JSONDataObject.hpp"


class JSONArray {
public:
  JSONArray();
  ~JSONArray();
  std::vector<JSONDataObject *> *listOfDataObjects();
  virtual JSONDataObject *jsonObjectNode() = 0;
  int numJSONObjects();
  void parseJSONArray(std::fstream &stream);
  virtual void print();

protected:
  std::vector<JSONDataObject *> *_listOfDataObjects;

};
#endif
