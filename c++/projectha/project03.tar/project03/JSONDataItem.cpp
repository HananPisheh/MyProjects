#include "JSONDataItem.hpp"

using namespace std;

JSONDataItem::JSONDataItem(){
  _attribute= _svalue="UNKNOWN";
  _ivalue=0;
  _isNumber= false;
  hasReadAnItem=false;  
}
  


void JSONDataItem::parseJSONItem(fstream &stream){
  char c;
  int number;
  if( !(stream >> c) || c != '"' ) {
    cout<<" ERoRR  for Qotation "<<c ;
    exit(1);}
  else
    _attribute=readQuotedString(stream);
    

  if( !(stream >> c) || c != ':' ){
      // print an error message and exit
      cout<<" Error for : ";
      exit(1);}
    // Now, we are ready to read the value part. It is either a string or a number.
    stream >> c;
    if( isdigit(c) ) {
      stream.unget();  // put the digit back into the stream so we read the number.
      stream >> number;
      _ivalue=number;
      _isNumber=true;
    }
    else{
     _svalue=readQuotedString(stream);
    _isNumber=false;
    }
    hasReadAnItem=true;}

  
string JSONDataItem::attribute(){return _attribute;}
int JSONDataItem::integerValue(){return _ivalue;}
string JSONDataItem::stringValue(){ return _svalue;}
bool JSONDataItem::isNumber(){
  return _isNumber;
}


 
void JSONDataItem::print(){ 
  //cout<<" number "<< _isNumber<<endl;
 cout<<" ivalue "<<_ivalue<<endl;
 cout<<" svalue  "<<_svalue  <<endl;
 cout<<" attribute "<< _attribute<<endl;
 
 cout<< endl;
 cout<<endl;
 cout <<endl;
}


string JSONDataItem::readQuotedString(fstream &stream){

char c;
 string value;
 while(!(stream.get(c)) || c !='"'){
      if(c=='\\'){
	// stream>>c;
	//stream.get(c);
	value+=c;
	stream.get(c);
      }
      value+=c;}
      return value;
}

/*
int main(){

  fstream myfile;
  myfile.open ("test.txt");
  JSONDataItem * tt = new JSONDataItem();
  tt->parseJSONItem(myfile);
  tt->print();
  myfile.close();	
  return 0;
}
*/

