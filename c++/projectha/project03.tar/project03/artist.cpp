//Hanan sedaghat pisheh

#include"Artist.hpp"
#include "Tracks.hpp"

using namespace std;

//string key;
//string value;
//unsigned number;

Artist::Artist(){
  _name="UNKNOWN";
  _realName="UNKNOWN";
  _profile="UNKNOWN";
  _primaryImage=NULL; //new ArtistImage();
    _secondaryImage= NULL; //new ArtistImage();
  _numImages="0";
  _artistID=0;
  _albums=new Albums();
  cachedName= cachedRealName= cachedProfile= cachedNumImages= cachedArtistID=false;
}

std::string Artist::profile()
{
  if( cachedProfile )
    return _profile;
  cachedProfile = true;
  return _profile = valueForStringAttribute("profile");
}


std::string Artist::realName()   {
  if( cachedRealName )
    return _realName;
  cachedRealName= true;
  return _realName = valueForStringAttribute("real_name");
    }
string Artist::artistName()
{
  if( cachedName )
    return _name;
  cachedName= true;
  return _name= valueForStringAttribute("artist_name");
}

string Artist::numImages(){
  if( cachedNumImages )
    return _numImages;
  cachedNumImages= true;
  return _numImages= valueForStringAttribute("num_images");
}


unsigned Artist::artistID()
{  
  if(cachedArtistID )
    return _artistID;
  cachedArtistID= true;
  return _artistID= valueForIntegerAttribute( "artist_id");
}

  
void Artist::print(){

  cout<<"name= "<<artistName()<<endl;
  cout<<"realname= "<<realName()<<endl;
cout<<"artist_id= "<<artistID()<<endl;
cout<<"profile= "<<profile()<<endl;
 cout<<"num_images= "<<numImages()<<endl;
  
  cout<< endl;
  cout<<endl;
  cout <<endl;
}

string Artist::htmlString(){
  
  stringstream begin;
  begin<<"<h2>"<< artistName()<<"</h2>";

  stringstream ainfo;
  ainfo<<"<tr><td class=\"tagName\">Number of Images:</td><td class=\"value\">"<<numImages();
  ainfo<<"</td></tr><tr><td>Profile:</td><td class=\"value\">"<<profile();
  ainfo<<"</td></tr></table><div class=\"clear\">&nbsp;</div><h2>Albums</h2><ol>";



  stringstream end;
  end<<"</table></li></ol>";


  

  string t = "";
  if(primaryImage()!= nullptr)
  t = primaryImage()->htmlString();
  else if(secondaryImage() != nullptr)
  t = secondaryImage()->htmlString();
  //  string h="";
  //return h;
    return begin.str() + t +  ainfo.str()    +  albums()->htmlString() + end.str() ;
  

}
  Artist::~Artist()
  {}



