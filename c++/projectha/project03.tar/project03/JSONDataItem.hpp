#ifndef JSONI
#define JSONI


#include<vector>
#include<fstream>
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
class JSONDataItem {
public:
  JSONDataItem();
  void parseJSONItem(fstream &stream);
  string attribute();
  int integerValue();
  string stringValue();
  bool isNumber();
  void print();  // purely for debugging -- any format you want

private:
  string _attribute, _svalue;
  int _ivalue;
  bool hasReadAnItem, _isNumber;
  string readQuotedString(fstream &stream);
};
#endif
