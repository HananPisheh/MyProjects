//Hanan sedaghat pisheh 
#include "Track.hpp"

using namespace::std;
//string key;
//string value;
//unsigned number;


Track::Track(){
  _artistName="UNKNOWN";
  _title="UNKNOWN";
  _albumName="UNKNOWN";
  _duration="";
  _position="UNKNOWN";
  _albumID=0;
  cachedName= cachedtitle= cachedalbumName= cachedduration= cachedposition=cachedalbumid= false;
}

std::string Track::artistName() {
  if( cachedName )
    return _artistName;
  cachedName = true;
  return _artistName = valueForStringAttribute("artist_name");}

std::string Track::title() {
  if( cachedtitle )
    return  _title;
  cachedtitle = true;
  return  _title = valueForStringAttribute("title");}
  
std::string Track::albumName() {
  if( cachedalbumName )
    return   _albumName;
  cachedalbumName= true;
  return  _albumName= valueForStringAttribute("album_name");}
unsigned Track::albumID() {
  if( cachedalbumid )
    return   _albumID;
  cachedalbumid= true;
  return  _albumID= valueForIntegerAttribute("album_id");}
std::string Track::duration() {
if( cachedduration )
  return _duration;
  cachedduration =true;
  return _duration=valueForStringAttribute("duration");}
std::string Track::position() {
if( cachedposition )
  return _position;
 cachedposition=true;
  return _position=valueForStringAttribute("position");}
 
void Track::print(){
  cout<<"title= "<<title() <<endl;
  cout<<"artist_name= "<< artistName()<<endl;
  cout<<"album_name= "<< albumName()<<endl;
  cout<<"album_id= "<< albumID()<<endl;
  cout<<"duration= "<< duration()<<endl;
  cout<<"position= "<< position()<<endl;
  
  cout<< endl;
  cout<<endl;
  cout <<endl;
}
string Track::htmlString(){
  stringstream ss;
  
     
  ss<< "<tr class=\"tracks\"><td class=\"trackName\">"<<title();
  ss<<"</td><td>"<<duration()<<"</td></tr>";
    //</table></li>


  //fstream outfile;
  //outfile.open("tracks_template.html");
  //while(outfile.good()){
    //char c;
    //outfile.get(c);
    //str += c;
    // }
  //  str.replace(str.find("<% tracks %>"),12,ss.str());
  //  outfile.close();
  // return  //"<h2>Tracklist</h2>"+
   return   ss.str();

}

Track::~Track(){}





