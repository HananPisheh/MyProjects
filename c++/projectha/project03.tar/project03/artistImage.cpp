//Hanan sedaghat pisheh

#include "ArtistImage.hpp"
#include "Artist.hpp"
#include "Track.hpp"

ArtistImage::ArtistImage(){

_height= 0;
_type="Primary";
_uri="UNKNOWN";
_width=0;
_artistID=0;
cachedTypeIMG=cachedArtistIMGID=false;

}


unsigned ArtistImage::artistID()
{
  if(cachedArtistIMGID )
   return _artistID;
  cachedArtistIMGID= true;
  return _artistID= valueForIntegerAttribute( "artist_id");
}



std::string ArtistImage::Type()
{
   if(cachedTypeIMG)
    return _type;
  cachedTypeIMG= true;
  return _type=valueForStringAttribute("type");
}








void ArtistImage::print(){
  cout<<"Type= "<<valueForStringAttribute("type")<<endl;
  cout<<"height "<<valueForIntegerAttribute("height")<<endl;
  cout<<"width"<<valueForIntegerAttribute("width")<<endl;
  cout<<"URI "<<valueForStringAttribute("uri")<<endl;
  cout<<"artistID "<<valueForIntegerAttribute("artist_id")<<endl;
  cout<< endl;
  cout<<endl;
  cout <<endl;
       }
  void ArtistImage::parseFromJSONstream(std::fstream &stream){}

std::string ArtistImage::htmlString(){
    stringstream ss;
    ss<<"<img class= \"image\" width= "<<valueForIntegerAttribute("width")/2;
    ss<< " height= "<<valueForIntegerAttribute("height")/2;
    ss <<" src= \""<<  valueForStringAttribute("uri")<<"\"><table class=\"artistInfo\">";
    //    cout<<Type();
    return ss.str();
  }




  
ArtistImage::~ArtistImage(){}

