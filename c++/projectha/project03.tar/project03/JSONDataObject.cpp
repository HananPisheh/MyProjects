#include "JSONDataObject.hpp"

JSONDataObject::JSONDataObject(){

   _listOfDataItems= new vector<JSONDataItem *> ;

}

void JSONDataObject::parseFromJSONstream(fstream &stream){
  char c;
  if( !(stream >> c) || c != '{') {
    // The first non-space character of a JSON object has to be '{'.
    // print some error message and exit the program
    //exit(1);

    cout<<" ERORR for {";
    exit(1);
  }
  do {
    
    JSONDataItem * values = new JSONDataItem();
    values->parseJSONItem(stream);
    //values->print();
    // _listOfDataItems.push_back (values);
     _listOfDataItems->push_back(values);
    stream>>c;
  } while( c != '}' );

}

JSONDataObject::~JSONDataObject(){
  for(unsigned i=0;i<_listOfDataItems->size();i++){
    delete _listOfDataItems->at(i);}
    delete _listOfDataItems;
}
string JSONDataObject::valueForStringAttribute(string s){

  for(unsigned i=0; i<(_listOfDataItems->size()); i++){

    //    str1.compare(str2) != 0
      if(((_listOfDataItems->at(i)->attribute()).compare(s) == 0 )  &&  (_listOfDataItems-> at(i) -> isNumber() == false ))   
      return _listOfDataItems->at(i)->stringValue();
        
      }
   return "not a string";   
}

int JSONDataObject::valueForIntegerAttribute(string s){

  for(unsigned i=0;i<(_listOfDataItems->size());i++){
    if(((_listOfDataItems->at(i)->attribute()).compare(s)==0) && (_listOfDataItems->at(i)->isNumber()==true))
      return _listOfDataItems->at(i)->integerValue();

  }
   
  return 0;
}
//virtual
void JSONDataObject::print(){}
/*

int main(){

  fstream myfile;
  myfile.open ("test.txt");
  //JSONDataItem * tt = new JSONDataItem();
  //tt->parseJSONItem(myfile);
  //tt->print();
  JSONDataObject * tt = new JSONDataObject();
  tt->parseFromJSONstream(myfile);
    
  myfile.close();
  return 0;
}


*/
