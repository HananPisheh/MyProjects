//Hanan sedaghat pisheh
#ifndef ABIMAGE
#define ABIMAGE

#include "JSONDataObject.hpp"
#include<fstream>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<sstream>

//class Artist;
//class Tracks;
class AlbumImage: public JSONDataObject {
public:
  AlbumImage();
  ~AlbumImage();
  std::string Type();//{return _type;}  
  unsigned AlbumID();
  unsigned Width() {return _width;}
  std::string URL();
  unsigned Height(){return _height;}
  std::string URI(){return _uri;}
  void print();
  void parseFromJSONstream(std::fstream &stream);
  std::string htmlString();
  unsigned albumID();


  //void setTracks(Tracks *tracks);
  //void setArtist(Artist *artist);
  //  Artist *artist() { return _artist; }
  //Tracks *tracks() { return _tracks; }


private:
  std::string _type, _uri;
  unsigned  _height, _width;
  //bool cachedTitle, cachedGenres, cachedYear, cachedNumImages	\
    // , cachedAlbumD, cachedNumTracks,
  bool cachedAlbumIMGID, cachedTypeIMG,cachedURL;
  unsigned _albumID ;



};
#endif
