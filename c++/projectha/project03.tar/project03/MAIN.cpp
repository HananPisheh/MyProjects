//Hanan sedaghat pisheh
#include "Tracks.hpp"
#include "Albums.hpp"
#include <fstream>
#include <cstring>
#include <stdio.h>
#include <vector>
#include <cstdlib>
#include "JSONArray.hpp"
#include "Artists.hpp"
#include "ArtistImages.hpp"
#include "AlbumImages.hpp"
#include <iostream>
#include <string>

using namespace std;

int main(){


  Artists * artists = new Artists();
  Tracks * tracks=new Tracks();
  Albums * albums =new Albums();
  ArtistImages * artistIMAGES =new ArtistImages();
  AlbumImages * albumIMAGES =new AlbumImages();

    artists->loadArtistsFromFile("artists.json");
    tracks->loadTracksFromFile("tracks.json");
   
    albums->loadAlbumFromFile("albums.json");   

    artistIMAGES->loadArtistImageFromFile("artistImages.json");
    albumIMAGES->loadAlbumImageFromFile("album_images_human_readable.json");
     
     
    
    albums->setTracksForAlbums(tracks);
    artists->setAlbumsForArtists(albums);
    artists->setImagesForArtists(artistIMAGES);
    albums->setImagesForAlbums(albumIMAGES);
   

    for(signed i=0 ; i< albums->numAlbums(); i++ )
      {
	string name="htmlfiles/";
	string each1;
	int alid=0;
	each1 +=albums->listOfAlbums()->at(i)->htmlString();
	alid=albums->listOfAlbums()->at(i)->albumID();
	stringstream hh;
	hh<<alid;
	name+= hh.str();
	name+=".html";
	string jadid=" ";
	
	jadid+=albums->listOfAlbums()->at(i)->htmlString();
	string m="";
	fstream moutfile;
	moutfile.open("album_template.html");
	while(moutfile.good()){
	  char c;
	  moutfile.get(c);
	  m += c;

             }
		
	m.replace(m.find("<% album_name %>"),16,albums->listOfAlbums()->at(i)-> title());
	m.replace(m.find("<% album_details %>"),19,jadid);

	ofstream newq;
	newq.open(name);
	newq<<m;
	moutfile.close();
	newq.close();
	
	}

  string master="";
  fstream outfile;
  outfile.open("artists_template.html");
  while(outfile.good()){
    char c;
    outfile.get(c);
    master += c;
  }





  string ssart;
  for(int i=0;i<artists->numArtists();i++)
    {// ssart+=artists->listOfArtists()->at(i)->htmlString();
      //  artists->listOfArtists()->at(i)->print();}
    }
  

  master.replace(master.find("<% artists %>"),13,artists->htmlString());
  ofstream htmlfile;
  htmlfile.open("master.html");
  htmlfile<<master<<endl;
  htmlfile.close();
  outfile.close();

  
  delete artists;
  delete tracks;
  delete albums;
  delete artistIMAGES;
  delete albumIMAGES;
  
    
  return 0;

}

