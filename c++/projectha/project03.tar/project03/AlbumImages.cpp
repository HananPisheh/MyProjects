//Hanan sedaghat pisheh
#include "AlbumImages.hpp"
//#include "AlbumImage.hpp"


AlbumImages::AlbumImages(){}

int AlbumImages::numAlbumImage(){

  return listOfAlbumImage()->size();
}
void AlbumImages::addAlbumImage(AlbumImage *albumImg){
  listOfAlbumImage()->push_back(albumImg);
}
AlbumImages *AlbumImages::albumImageWithID(unsigned int aID){
  AlbumImages *out =new AlbumImages();
  for(auto& it : *listOfAlbumImage())
    {if(it->albumID()==aID)
	out->addAlbumImage(it);
    }

  return out;

  
}
void AlbumImages::loadAlbumImageFromFile(std::string AlbumImageFileName){

  std::fstream albumIMGStream;
  albumIMGStream.open(AlbumImageFileName.c_str(), std::fstream::in);
  parseJSONArray(albumIMGStream);
  albumIMGStream.close();
  cout<<endl;
 

}
std::string AlbumImages::htmlString(){

}


void AlbumImages:: runAsserts(){} // used for checking the integrity of this class.

AlbumImages::~AlbumImages(){}
