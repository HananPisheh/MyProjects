//Hanan sedaghat pisheh

#ifndef TRAK
#define TRAK
#include "JSONDataObject.hpp"
#include<fstream>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<sstream>

class Track: public JSONDataObject{

public:
  Track();
  ~Track();
  
  std::string artistName();// {return _artistName;}
  std::string title();// {return _title;}
  std::string albumName();// {return _albumName;}
  unsigned albumID();// {return _albumID;}
  std::string duration() ;//{return _duration;}
  std::string position();// {return _position;}
  void print();
  //  void parseFromJSONstream(std::fstream &stream);
  std::string htmlString();

  
private:
  std::string _artistName, _title, _albumName, _duration, _position;
  unsigned _albumID;
  bool cachedName, cachedtitle, cachedalbumName, cachedduration, cachedposition, cachedalbumid;
  
};
#endif
