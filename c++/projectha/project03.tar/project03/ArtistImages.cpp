//Hanan sedaghat pisheh
#include "ArtistImages.hpp"



ArtistImages::ArtistImages(){}

int ArtistImages::numArtistImage(){

  return listOfArtistImage()->size();
 
}
void ArtistImages::addArtistImage(ArtistImage *artistImg){
  listOfArtistImage()->push_back(artistImg);
}

ArtistImages *ArtistImages::artistImageWithID(unsigned int aID){

  ArtistImages *out =new ArtistImages;
   for(auto& it : *listOfArtistImage())
   {if(it->artistID()==aID)
       out->addArtistImage(it);
  }

  return out;

}
void ArtistImages::loadArtistImageFromFile(std::string ArtistImageFileName){

  std::fstream artistIMGStream;
  artistIMGStream.open(ArtistImageFileName.c_str(), std::fstream::in);
  parseJSONArray(artistIMGStream);
  artistIMGStream.close();
  cout<<endl;
 

}
std::string ArtistImages::htmlString(){
  //  cout<<"html imagesss";
  // std::string ss;  
  //for(int i=0; i<numArtistImage();i++)
  //ss+=listOfArtistImage()->at(i)->htmlString();
  // return ss;
  

}


void ArtistImages:: runAsserts(){} // used for checking the integrity of this class.

ArtistImages::~ArtistImages(){}
