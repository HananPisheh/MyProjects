#ifndef ALBUMIMAGES
#define ALBUMIMAGES
#include "AlbumImage.hpp"
#include "JSONArray.hpp"
//#include "JSONDataObject.hpp"


class AlbumImages: public JSONArray
{
public:
  AlbumImages();
  ~AlbumImages();
  int numAlbumImage();
  void addAlbumImage(AlbumImage * albumImg );
  AlbumImages *albumImageWithID(unsigned int aID);
  void loadAlbumImageFromFile(std::string AlbumImageFileName);
  std::string htmlString();
  JSONDataObject *jsonObjectNode() { return new AlbumImage();  }
  //  void setAlbumsForArtists(Albums *albums);
  //void setImagesForArtists(ArtistImages *);
  std::vector<AlbumImage *> *listOfAlbumImage() { return (std::vector<AlbumImage *> *) _listOfDataObjects;  }
  void runAsserts();  // used for checking the integrity of this class.
};

#endif


