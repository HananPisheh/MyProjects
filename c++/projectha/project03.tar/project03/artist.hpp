//Hanan sedaghat pisheh
#ifndef AAAT
#define AAAT
#include "JSONDataObject.hpp"
#include<fstream>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<sstream>
#include "Albums.hpp"
//class Tracks;//
//#include "Tracks.hpp"
#include "ArtistImages.hpp"
class Artist: public JSONDataObject {
public:
  Artist();
  ~Artist();

  
 std::string profile();
 std::string realName() ;  //{ return _realName; }
 std::string artistName();// { return _name; }
  // numImages is a string in the JSON file, but you
  // should convert it to unsigned when you parse
  // from the JSON stream.
 string numImages() ;//{ return _numImages; }
 unsigned  artistID() ;  //{ return _artistID;  }  
 void print();
 void parseFromJSONstream(std::fstream &stream);
 std::string htmlString();
 void setAlbums(Albums *albums) { _albums = albums; }
 Albums *albums() { return _albums; }
ArtistImage *&primaryImage()       { return _primaryImage;   }
 ArtistImage *&secondaryImage()     { return _secondaryImage; }

  private:
  std::string _name, _realName, _profile, _numImages;
  unsigned _artistID;
    bool cachedName, cachedRealName, cachedProfile, cachedNumImages, cachedArtistID;

    // the following 3 variables are new to this project.
    ArtistImage *_primaryImage, *_secondaryImage;  
    Albums *_albums;
  };


  
  
#endif
