#ifndef ALBUMS
#define ALBUMS

#include "JSONArray.hpp"
#include "Album.hpp"
#include "AlbumImages.hpp"
#include "Tracks.hpp"

class Albums: public JSONArray
{
public:
  Albums();
  ~Albums();

  int numAlbums();
  void addAlbum(Album *albums);
  Albums *albumWithID(unsigned int aID);
  void loadAlbumFromFile(std::string fileName);
  std::string htmlString();
  JSONDataObject *jsonObjectNode() { return new Album();  }
  void setTracksForAlbums(Tracks *tracks);
  void setImagesForAlbums(AlbumImages *);
  std::vector<Album *> *listOfAlbums() { return (std::vector<Album *> *) _listOfDataObjects;\
  }
  void runAsserts();  // used for checking the integrity of this class.
};

#endif
