#include "Albums.hpp"
#include <vector>

Albums::Albums(){}
Albums::~Albums(){}

int Albums::numAlbums(){
  return listOfAlbums()->size();
}
void Albums::addAlbum(Album *albums){
  listOfAlbums()->push_back(albums);

  
}
Albums* Albums::albumWithID(unsigned int aID){
  Albums *t = new Albums();
  for(auto& it : *listOfAlbums())
    {
      if(it->artistID()==aID)
	t->addAlbum(it);
	  
}
return t;

}
void Albums::loadAlbumFromFile(std::string AlbumsFileName){
  std::fstream albumStream;
  albumStream.open(AlbumsFileName.c_str(), std::fstream::in);
  parseJSONArray(albumStream);
  albumStream.close();
  cout<<endl;
  
}

std::string Albums::htmlString(){

  std::string ss;
  // ss='first';
  for(int i=0; i<numAlbums();i++)
    ss+=listOfAlbums()->at(i)->htmlString();
  return ss;
}
  
  //for(auto& i :*listOfAlbums())
  // i->htmlString();
  //  return "hhhhhhhhhhhhhhhhhh";

/* 
    stringstream ss;
    ss << "  <li><p> Album ID: " << albumID() << "</p>\n";
    ss<< "      <ul>\n" ;
    ss << "      <li><p>number of tracks: "<< numTracks() <<"</p></li>\n";
    ss<<"<li><p>year:" <<year()<<"</p></li>\n";
    ss<< "<li><p>genres:"<<genres()<<"</p></li>\n";
    ss<<"<li><p>artist id: :"<< artistID()<<"</p></li>\n";
    ss<<"<li><p>number of Images:"<< numImages()<<"</p></li>\n";
    ss<<"<li><p>title: "<< title()<<"</p></li>\n";
    ss<<  "</ul>\n"<<"</li>"<<endl;
    ss<<endl;
    ss<<endl;

    return ss.str();  

*/



void Albums::setTracksForAlbums(Tracks *tracks){
  /*
  for(auto& albm : *listOfAlbums()){
    
    Tracks *temp = new Tracks();
    // albm->albumID()
      for(auto& trk : *tracks->listOfTracks() ){

	if(albm->albumID()==trk->albumID())
	  //albm->setTracks(tracks);
	  temp->addTrack(trk);
      }
      albm->setTracks(temp);
  }
  */
  
  for(auto& albm : *listOfAlbums()){
    unsigned id = albm->albumID();
    Tracks * temp =tracks->TracksalbumWithID(id);
    albm->setTracks(temp);
  }
}

void Albums::setImagesForAlbums(AlbumImages * albi){
  for(auto& it : *listOfAlbums()){
    unsigned id= it->albumID();
    AlbumImages  * temp = albi->albumImageWithID(id);
    
    for (int i=0; i< temp->numAlbumImage(); i++){
      // cout<<"number of images"<<temp->listOfArtistImage()->at(i)->Type()<<endl;
      //cout<<"ta inja" ;
      if(temp->listOfAlbumImage()->at(i)->Type()=="primary")
	it->primaryImage()=(temp->listOfAlbumImage()->at(i));
      it->secondaryImage()=(temp->listOfAlbumImage()->at(i));
    }
  }
}


void Albums::runAsserts(){}
