#include "Artists.hpp"


Artists::Artists(){}


int Artists::numArtists(){

  return listOfArtists()->size();
}
  void Artists::addArtist(Artist *artists){
    listOfArtists()->push_back(artists);
  }

  Artist *Artists::artistWithID(unsigned int aID){
    for(auto& it : *listOfArtists())
      {if(it->artistID()==aID)
	  return it;
      }
    return NULL;
  }
  void Artists::loadArtistsFromFile(std::string ArtistsFileName){

    std::fstream artistsStream;
    artistsStream.open(ArtistsFileName.c_str(), std::fstream::in);
    parseJSONArray(artistsStream);
    artistsStream.close();
    cout<<endl;   
  }

 std::string Artists::htmlString(){

   std::string ss;

   for(int i=0; i<numArtists();i++)
     ss+=listOfArtists()->at(i)->htmlString();
   return ss;
 }

void Artists::setAlbumsForArtists(Albums *albums){
    for(auto& it :*listOfArtists()){  
       unsigned id= it->artistID();
    	Albums * temp = albums->albumWithID(id);
    	  it->setAlbums(temp);

	  for(int i=0 ; i<temp->numAlbums();i++)
	    temp->listOfAlbums()->at(i)->setArtist(it);
  }
}
void Artists::setImagesForArtists(ArtistImages * arti){

    for(auto& it : *listOfArtists()){
       unsigned id= it->artistID();
       ArtistImages  * temp = arti->artistImageWithID(id);      


       for (int i=0; i< temp->numArtistImage(); i++){
	 // cout<<"number of images"<<temp->listOfArtistImage()->at(i)->Type()<<endl;
	 //cout<<"ta inja" ;
	 if(temp->listOfArtistImage()->at(i)->Type()=="primary")
	 it->primaryImage()=(temp->listOfArtistImage()->at(i));
	 it->secondaryImage()=(temp->listOfArtistImage()->at(i));
       }      
}
    }


void Artists::runAsserts(){}  // used for checking the integrity of this class.

Artists:: ~Artists(){}
