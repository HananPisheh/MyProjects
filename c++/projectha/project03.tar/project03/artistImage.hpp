//Hanan sedaghat pisheh
#ifndef ARIMAGE
#define ARIMAGE

#include "JSONDataObject.hpp"
#include<fstream>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<sstream>

//class Artist;
//class Tracks;
class ArtistImage: public JSONDataObject {
public:
  ArtistImage();
  ~ArtistImage();
  unsigned artistID();
 std::string Type();// { return _type=valueForStringAttribute("type");}   
  //  std::string ArtistID() {return _artistID;}
  unsigned Width() {return _width;}
  unsigned Height(){return _height;}
  std::string URI(){return _uri;}
  void print();
  void parseFromJSONstream(std::fstream &stream);
  std::string htmlString();

  //void setTracks(Tracks *tracks);
  //void setArtist(Artist *artist);
  //Artist *artist() { return _artist; }
  //Tracks *tracks() { return _tracks; }


private:
  std::string _type, _uri;
  unsigned  _height, _width, _artistID;
  // bool cachedTitleIMG, cachedGenresIMG, cachedYearIMG, cachedNumImagesIMG,cachedAlbumDIMG, cachedNumTracksIMG,
    bool cachedArtistIMGID, cachedTypeIMG;
  // Tracks *_tracks;
  //Artist *_artist;


};
#endif
