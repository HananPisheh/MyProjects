#include "JSONArray.hpp"


JSONArray::JSONArray(){
  
  _listOfDataObjects= new vector<JSONDataObject *> ;

}
  

std::vector<JSONDataObject *> * JSONArray::listOfDataObjects()
{ return _listOfDataObjects; }


//virtual JSONArray::JSONDataObject *jsonObjectNode() = 0;


int JSONArray::numJSONObjects(){return  _listOfDataObjects->size();}


void JSONArray::parseJSONArray(std::fstream &stream)
  {
    //std::cout << "Reading array\n";
    char cc[2], prev = ' ';
    cc[1] = '\0';
   
    if( ! (stream >> cc[0]) || cc[0] != '[' )  // we expect this to be a open-bracket character.
      std::cout << "ERROR: failed to find opening [ for list\n";
   
      // print an error message and exit
    do {
      //std::cout << "Reading 2sencnd  item\n";
      JSONDataObject *dItem = jsonObjectNode();
      dItem->parseFromJSONstream(stream);
      _listOfDataObjects->push_back(dItem);
      
      if( ! (stream >> cc[0]) )
	  // print an error message and exit
	
	if( cc[0] != ']' && cc[0] != ',' )
	  // print an error message and exit
	  std::cout<<"ERROR";
    } while( cc[0] != ']' );
    //  std::cout << cc[0] << std::endl;
  }

void JSONArray::print(){

  
  std::cout <<"Item count: " << _listOfDataObjects->size() << std::endl;
  for (auto& item : *_listOfDataObjects) {
    item->print();
  }


}



//std::vector<JSONDataObject *> *_listOfDataObjects;



JSONArray::~JSONArray(){

  for(unsigned i=0;i<_listOfDataObjects->size();i++){
  delete _listOfDataObjects->at(i);}
 delete _listOfDataObjects;
}





